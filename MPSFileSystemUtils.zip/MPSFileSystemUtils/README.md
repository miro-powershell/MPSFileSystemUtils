# MPSFileSystemUtils
PowerShell module with File System Utilities

Contains Advanced Functions:
    Start-MPSFileSystemWatcher,
    Stop-MPSFileSystemWatcher
